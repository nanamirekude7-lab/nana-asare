ASAGREY PLUS CONSTRUCTION LIMITED — Website Package

PREVIEW: Extract the ZIP and open index.html in a browser.
PUBLISH: Upload index.html and the complete assets folder to your web host's public web directory (often public_html).

IMPORTANT: Gallery photos are illustrative concept visuals, not verified photos of your completed projects. Replace them with your own actual project photos before publishing. Confirm project names/descriptions and obtain client permission where needed.

CONTACT FORM: The form opens the visitor's email application; it does not store submissions. For a fully hosted form, connect a secure form service or server-side email handler.

Before launch, verify contact details, mobile display, and your hosting/domain settings.
